<?php
$nav = '<nav><ul>';
$nav .= '<li><a href="mainJK.php">Main page</a></li> ';
$nav .= '<li><a href="viewJK.php">View keto foods list</a></li> ';
$nav .= '<li><a href="requestJK.php">equest a food Item</a></li> ';
$nav .= '<li><a href="view_tempJK.php">See Temperature</a></li> ';
$nav .= '<li><a href="view_timeJK.php">View Local Prayer Time</a></li> ';
$nav .= '</ul></nav>';
echo $nav;
?>
