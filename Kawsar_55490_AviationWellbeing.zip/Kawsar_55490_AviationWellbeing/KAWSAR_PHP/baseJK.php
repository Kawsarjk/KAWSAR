<?php
$username = 'root';
$password = '';
$server = 'localhost';
$database = 'AviationWellbeingJK';
?>