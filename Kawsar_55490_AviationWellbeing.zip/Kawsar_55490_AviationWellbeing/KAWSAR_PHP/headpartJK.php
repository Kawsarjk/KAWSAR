<?php
$headPartJK = '<title>Holiday Hype</title>';
$headPartJK .= '<meta charset="UTF-8">';
$headPartJK .= '<link rel="stylesheet" href="KAWSAR_CSS\styleJK.css">';
echo $headPartJK;
?>
