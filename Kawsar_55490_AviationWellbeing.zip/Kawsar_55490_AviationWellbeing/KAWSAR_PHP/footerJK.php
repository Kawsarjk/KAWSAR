<?php include 'KAWSAR_PHP\navJK.php'; ?>
<?php 
$footerJK = '<h6>WELL-BEING FOR FREQUENT TRAVELLERS</h6>';
echo $footerJK;
?>