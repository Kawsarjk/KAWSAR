<?php
$articleJK = 'The more you travel,<br>';
$articleJK .= 'the more you will know.<br>';
$articleJK .=  'The more you explore,<br>';
$articleJK .= 'the more you will grow.<br>';
echo $articleJK;
?>
