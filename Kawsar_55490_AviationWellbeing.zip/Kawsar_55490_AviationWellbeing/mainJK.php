<!DOCTYPE html>
<html lang="EN">
<head>
<?php include 'KAWSAR_PHP\headpartJK.php'?>
<?php include 'KAWSAR_PHP\requestEntryJK.php'?>
<?php include 'KAWSAR_PHP\finalEntryJK.php'?>
</head>
<body>
    <header>
    <?php include 'KAWSAR_PHP\headerJK.php'?>
    </header>
    <article>
    <?php include 'KAWSAR_PHP\articleJK.php'?>
    </article>
    <footer><?php include 'KAWSAR_PHP\footerJK.php'?></footer>
</body>
</html>